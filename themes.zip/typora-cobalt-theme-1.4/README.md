# Cobalt theme for Typora
Created by [Kent Pribbernow](https://www.github.com/elitistsnob)

A dark theme inspired by Wes Bos's [Cobalt](https://www.github.com/wesbos) theme for Sublime.

![Latest Release Version](https://img.shields.io/github/v/release/elitistsnob/typora-cobalt-theme)
![Latest Release Date](https://img.shields.io/github/release-date/elitistsnob/typora-cobalt-theme)
![Download Count](https://img.shields.io/github/downloads/elitistsnob/typora-cobalt-theme/total)

#### If you like this theme, consider donating. 
[![ko-fi](https://www.ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/R5R51EVX9)

![Splash screen](images/screenshot1.png)

![Splash screen](images/screenshot2.png)

![Splash screen](images/screenshot3.png)

![Splash screen](images/screenshot4.png)
